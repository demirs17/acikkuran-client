<?php
$servername = "localhost";
$username = "emr13amiirxyz_kuran_admin";
$password = "emr13amiirxyz_kuran_admin";
$dbname = "emr13amiirxyz_kuran";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$arr = [];

$sure_no = isset($_GET["sure_no"]) ? $_GET["sure_no"] : "";
$ayet_no = isset($_GET["ayet_no"]) ? $_GET["ayet_no"] : "";

$sql = "SELECT * from favori_ayetler where sure_no = '". $sure_no ."' and ayet_no = '". $ayet_no ."'";

$result = $conn->query($sql);

//print_r($result);

header("Content-type: application/json");
if ($result->num_rows > 0) {
    echo 1;
    //while ($row = $result->fetch_assoc()) {
    //    array_push($arr, $row);
    //}
} else {
    echo 0;
}

//header("Content-type: application/json");
//echo json_encode($arr, JSON_NUMERIC_CHECK);

$conn->close();
?>