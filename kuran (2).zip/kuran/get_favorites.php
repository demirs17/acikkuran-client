<?php
$servername = "localhost";
$username = "emr13amiirxyz_kuran_admin";
$password = "emr13amiirxyz_kuran_admin";
$dbname = "emr13amiirxyz_kuran";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$arr = [];


$sql = "SELECT * FROM favori_ayetler";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        array_push($arr, $row);
    }
} else {
}

header("Content-type: application/json");
echo json_encode($arr, JSON_NUMERIC_CHECK);

$conn->close();
?>