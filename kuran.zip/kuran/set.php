<?php
$servername = "localhost";
$username = "emr13amiirxyz_kuran_admin";
$password = "emr13amiirxyz_kuran_admin";
$dbname = "emr13amiirxyz_kuran";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}
header("Content-type: application/json");


$anahtar = isset($_GET["anahtar"]) ? $_GET["anahtar"] : die("0");
$deger = isset($_GET["deger"]) ? $_GET["deger"] : die("0");

//$sql = "update gorevler set baslik = '".$baslik."', kategori = '".$kategori."', tarih = '".$tarih."', saat = '".$saat."' where id = " . $id;
$sql = "UPDATE preferences SET deger = '". $deger ."' WHERE anahtar = '" . $anahtar . "'";
//echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "1";
} else {
    echo "0";
    //echo "Hata: " . $conn->error;
}


$conn->close();
?>