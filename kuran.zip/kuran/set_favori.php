<?php
$servername = "localhost";
$username = "emr13amiirxyz_kuran_admin";
$password = "emr13amiirxyz_kuran_admin";
$dbname = "emr13amiirxyz_kuran";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}
header("Content-type: application/json");


$sure_no = isset($_GET["sure_no"]) ? $_GET["sure_no"] : die("0");
$ayet_no = isset($_GET["ayet_no"]) ? $_GET["ayet_no"] : die("0");


$sql = "SELECT * from favori_ayetler where sure_no = '". $sure_no ."' and ayet_no = '". $ayet_no ."'";

$result = $conn->query($sql);

//print_r($result);

header("Content-type: application/json");
if ($result->num_rows > 0) {
    $sql = "delete from favori_ayetler where sure_no = '". $sure_no ."' and ayet_no = '". $ayet_no ."'";
    if ($conn->query($sql) === TRUE) {
        echo "1";
    } else {
        echo "0";
    }
} else {
    $sql = "insert into favori_ayetler(sure_no, ayet_no) values(".$sure_no.", ".$ayet_no.")";
    if($conn->query($sql) === TRUE){
        echo "1";
    }else{
        echo "0";
    }
}




//$sql = "UPDATE preferences SET deger = '". $deger ."' WHERE anahtar = '" . $anahtar . "'";
//echo $sql;

//if ($conn->query($sql) === TRUE) {
//    echo "1";
//} else {
//    echo "0";
    //echo "Hata: " . $conn->error;
//}


$conn->close();
?>